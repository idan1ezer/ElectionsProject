package RoniVeIdan;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner scan = new Scanner(System.in);
		Elections elections=StartElection(scan);
		Ballot b1=new Ballot("Bat Iftach", "Regular");
		Ballot b2=new Ballot("Hamaapilim", "Regular");
		Ballot b3=new Ballot("Vaizman", "Infected");
		Ballot b4=new Ballot("Alenbi", "Soldiers");
		elections.addBallot(b1);
		elections.addBallot(b2);
		elections.addBallot(b3);
		elections.addBallot(b4);
		MyDate newDate1=new MyDate(24,10,1996);
		PoliticalParty p1=new PoliticalParty("Rak Bibi", "Right", newDate1);
		MyDate newDate2=new MyDate(25,04,1975);
		PoliticalParty p2=new PoliticalParty("King Yair", "Left", newDate2);
		MyDate newDate3=new MyDate(27,05,1987);
		PoliticalParty p3=new PoliticalParty("Luis The Dog", "Central", newDate3);
		elections.addPoliticalParty(p1);
		elections.addPoliticalParty(p2);
		elections.addPoliticalParty(p3);
		Citizen c1=new Citizen("Roni Aronson", 315315739, 1996, "Bat Iftach", false , false);
		Citizen c2=new Citizen("Idan Ezer", 132456789, 1995, "Hamaapilim", false , false);
		Infected c3=new Infected("Kim K", 124356789, 1980, "Vaizman", true , false, true);
		Citizen c4=new Citizen("Kanye W", 273648596, 2000, "Alenbi", false , false);
		Candidate c5=new Candidate("Bambi Levy", 585166918, 1998, "Bat Iftach", false , true, 1 ,"King Yair");
		Candidate c6=new Candidate("Tor", 148298922, 1993, "Hamaapilim", false , true, 1 ,"Rak Bibi");
		Candidate c7=new Candidate("Luis", 708134999, 1955, "Hamaapilim", false , true, 1 ,"Luis The Dog");
		Citizen c8=new Citizen("Gal", 730203040, 2001, "Alenbi", false , false);
		elections.addCitizen(c1);
		elections.addCitizen(c2);
		elections.addInfected(c3);
		elections.addCitizen(c4);
		elections.addCandidate(c5);
		elections.addCandidate(c6);
		elections.addCandidate(c7);
		elections.addCitizen(c8);
		boolean prog = false;
		
		
		System.out.println("Enter your choise of exe");
		System.out.println(" 1 - Add ballot \n 2 - Add citizen \n 3 - Add political party \n 4- Add candidate \n 5- View all ballots details \n 6-View all citizens details \n 7-View all political parties details \n 8- Go vote \n 9- View result \n -1- Exit");
		int key = 0;

		while (prog == false) {
			key = scan.nextInt();
			switch (key) {
			case 1:
				elections.addBallot(scan);
				break;
			case 2:
				elections.addCitizen(scan);
				break;
			case 3:
				elections.addPoliticalParty(scan);
				break;
			case 4:
				elections.addCandidate(scan);
				break;
			case 5:
				elections.showAllBallots();
				break;
			case 6:
				elections.showAllCitizens();
				break;
			case 7:
				elections.showAllPoliticalParties();
				break;
			case 8:
				elections.goVote();
				break;
			case 9:
				elections.showElectionResult();
			case -1:
				System.out.println("Thank you, and good bye babe!");
				prog = true;
				break;
			default :
				System.out.println("Please pick the right number from the menu tembel");
				}
			}
			scan.close();
	}

		
		

	
	
	public static Elections StartElection(Scanner scan) throws FileNotFoundException {
		System.out.println("enter month");
		int month=scan.nextInt();
		System.out.println("enter year:");
		int year=scan.nextInt();
		Elections elections = new Elections(month, year);
		return elections;
	}

}
