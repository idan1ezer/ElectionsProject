package RoniVeIdan;

import java.util.Scanner;

public class Citizen {
	
	protected String name;
	protected int id;
	protected int year;
	protected String whichBallot;
	protected boolean isIsolated;
	protected boolean isCandidate;
	protected boolean isSoldier;
	protected boolean isVoting;
	protected String vote;
	
	public Citizen(String name, int id, int year, String wichBallot,boolean isIsolated, boolean isCandidate) {
		this.name=name;
		this.id=id;
		this.year=year;
		this.whichBallot=wichBallot;
		this.isIsolated=isIsolated;
		if(year<1999||year>2002)
			this.isSoldier=false;
		else
			this.isSoldier=true;
		this.isCandidate = isCandidate;
	}
	
	public Citizen (Scanner scan) {
		this.name = scan.next();
		this.id = scan.nextInt();
		this.year = scan.nextInt();
		this.whichBallot = scan.next();
		this.isIsolated = scan.nextBoolean();
		if(year<1999||year>2002)
			this.isSoldier=false;
		else
			this.isSoldier=true;
		this.isCandidate = scan.nextBoolean();
		
	}
	
	//���� �� ������ �� ����� ������� �����
	public int getVotes() {
		PoliticalParty[]parties=Elections.get_partiesList();
		for (int i = 0; i < parties.length; i++) {
			if(this.vote.equals(parties[i].getName()))
				return parties[i].getId();
		}
		return -1;
	}
	public String getWhichBallot() {
		return this.whichBallot;
	}
	public void setIsVoting(boolean answer) {
		this.isVoting=answer;
	}
	public boolean getIsSoldier() {
		return this.isSoldier;
	}
	public void setVote(String vote) {
		this.vote=vote;
	}
	public boolean getIsVoting() {
		return this.isVoting;
	}
	public String getName() {
		return this.name;
	}
	
	public String getBallot() {
		return this.whichBallot;
	}
	public String getVote() {
		return this.vote;
	}

	@Override
	public boolean equals(Object other) {
		if(!(other instanceof Citizen))
			return false;
		
		Citizen temp = (Citizen)other;
		return (temp.id == id);
	}
	@Override
	public String toString() {
		String str1, str2;
		if(isIsolated == true)
			str1 = "isolated";
		else
			str1 = "not isolated";
		if(isSoldier==true)
			str2="soldier";
		else
			str2="not a soldier";
		return "Citizen " + name + ", id:" + id + ", " + (2020-year) + " years old, votes in " + whichBallot
				+ ", the citizen is " + str1 +", the citizen is " + str2 + ", and votes for " + vote;
	}

	
	
	
	
	
}
