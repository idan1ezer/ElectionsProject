package RoniVeIdan;

import java.util.Scanner;

public class Infected extends Citizen {
	
	private boolean protectiveSuit;
	
	public Infected(String name, int id, int year, String wichBallot,boolean isIsolated,boolean isCandidate, boolean protectiveSuit) {
		super(name,id,year,wichBallot,isIsolated,isCandidate);
		this.protectiveSuit=protectiveSuit;
	}
	
	public boolean getProtectiveSuit() {
		return protectiveSuit;
	}
	@Override
	public boolean equals(Object other) {
		if(!(other instanceof Citizen))
			return false;
		
		if(!(super.equals(other)))
			return false;
	
		return true;
	}
	@Override
	public String toString() {
		String str;
		if(protectiveSuit == true)
			str = "has protective suit";
		else
			str = "has not protective suit";
		return super.toString()+" ,the citizen is infected and " + str;
	}
}
