package RoniVeIdan;

import java.util.Scanner;

public class PoliticalParty {
	private enum Wing {Right, Left, Central};
	
	private int id;
	private String name;
	private Wing wing;
	private MyDate date;
	private Candidate []candidates;
	private int candidateCounter=0; 
	private static int counter=0;
	private int totalVotes=0;
	
	
	public PoliticalParty(String name, String wing, MyDate date) {
		this.name=name;
		this.wing=Wing.valueOf(wing);;
		this.date=date;
		this.candidates=new Candidate[3];
		id=counter++;
	}
	
	public PoliticalParty(Scanner scan) {
		this.name=scan.next();
		this.wing=wing.valueOf(scan.next());
		this.date=new MyDate(scan);
		this.candidates=new Candidate[candidates.length];
		for (int i = 0; i < candidates.length; i++) {
			this.candidates[i]=new Candidate(scan);
		}
		id=++counter;
	}
	public void setTotalVotes() {
		totalVotes++;
	}
	public int getId() {
		return id;
	}

	public String getName() {
		return this.name;
	}
	public boolean addCandidate(Candidate newCandidate) {
		if(candidateCounter==candidates.length)
			extandCandidate();
		candidates[candidateCounter]=newCandidate;
		candidateCounter++;
		return true;
	}
	public boolean extandCandidate() {
		Candidate []newCandidate=new Candidate[this.candidates.length*2];
		for (int i = 0; i < this.candidates.length; i++) {
			if(candidates[i]!=null)
				candidates[i]=newCandidate[i];
		}
		return setCandidates(newCandidate);
	}
	private boolean setCandidates(Candidate[] newCandidate) {
		this.candidates=newCandidate;
		return true;
	}
	public int getTotalVotes() {
		return totalVotes;
	}

	@Override
	public boolean equals(Object other) {
		if(!(other instanceof PoliticalParty))
			return false;
		
		PoliticalParty temp = (PoliticalParty)other;
		return (temp.id == id);
	}
	@Override
	public String toString() {

		return "Political party " + name + ", id:" + id + ", is " + wing + " wing, created at " + date.getDate()
				+ ", the party has " + candidateCounter + " candidates.";
	}


}
