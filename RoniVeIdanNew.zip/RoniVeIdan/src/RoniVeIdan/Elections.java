package RoniVeIdan;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Elections {

	private int month;
	private int year;

	private static Citizen[] electors = new Citizen[37];
	private int citizenCounter = 0;
	private static PoliticalParty[] partiesList = new PoliticalParty[4];
	private int politicalPartyCounter = 0;
//	private static Candidate[] candidates;
	private Ballot[] ballots = new Ballot[5];
	private int ballotCounter = 0;
	private static Citizen[]isVoted=new Citizen[37];
	public Elections(int month, int year) {
		this.month = month;
		this.year = year;
	}

	/*
	 * public Elections(Scanner scan) throws FileNotFoundException{
	 * 
	 * this.month = scan.nextInt(); this.year = scan.nextInt(); for (int i = 0; i <
	 * partiesList.length; i++) { partiesList[i] = new PoliticalParty(scan); } for
	 * (int i = 0; i < ballots.length; i++) { ballots[i] = new Ballot(scan); } for
	 * (int i = 0; i < ballots.length; i++) { Citizen
	 * []citizens=ballots[i].getCitizens(); int count=0; for (int j = 0; j <
	 * electors.length; j++) { if(citizens[count] instanceof Candidate) count++;
	 * else { this.electors[j]=citizens[count]; count++; }
	 * 
	 * } } scan.close(); }
	 */

	// check if not duplicated for ALL
	public void addBallot(Ballot newBallot) {
		if (ballotCounter == ballots.length)
			extandBallot();
		ballots[ballotCounter] = newBallot;
		ballotCounter++;
	}

	public void addBallot(Scanner scan) {
		System.out.println("enter ballot's address");
		String address = scan.next();
		System.out.println("enter ballot's type");
		String type = scan.next();
		Ballot newBallot = new Ballot(address, type);
		addBallot(newBallot);

	}

	public boolean setBallots(Ballot[] newBallots) {
		this.ballots = newBallots;
		return true;
	}

	public boolean extandBallot() {
		Ballot[] newBallots = new Ballot[this.ballots.length * 2];
		for (int i = 0; i < this.ballots.length; i++) {
			if (ballots[i] != null)
				newBallots[i] = ballots[i];
		}
		return setBallots(newBallots);
	}

	public void addPoliticalParty(Scanner scan) {
		System.out.println("enter PoliticalParty's name");
		String name = scan.next();
		System.out.println("enter PoliticalParty's wing");
		String wing = scan.next();
		MyDate date = new MyDate(scan);
		PoliticalParty newPoliticalParty = new PoliticalParty(name, wing, date);
		addPoliticalParty(newPoliticalParty);
	}

	public void addPoliticalParty(PoliticalParty newPoliticalParty) {
		if (politicalPartyCounter == this.partiesList.length)
			extandPartiesList();
		partiesList[politicalPartyCounter] = newPoliticalParty;
		politicalPartyCounter++;
	}

	public boolean setPoliticalParty(PoliticalParty[] newpartiesList) {
		this.partiesList = newpartiesList;
		return true;
	}

	public boolean extandPartiesList() {
		PoliticalParty[] newpartiesList = new PoliticalParty[this.partiesList.length * 2];
		for (int i = 0; i < this.partiesList.length; i++) {
			if (this.partiesList[i] != null)
				newpartiesList[i] = this.partiesList[i];
		}
		return setPoliticalParty(newpartiesList);
	}

	public void addCitizen(Scanner scan) {
		System.out.println("enter Citizen's name");
		String name = scan.next();
		System.out.println("enter Citizen's id");
		int id = scan.nextInt();
		System.out.println("enter Citizen's year");
		int year = scan.nextInt();
		System.out.println("enter ballot's address");
		String address = scan.next();
		System.out.println("is isolated (true\false)");
		boolean isIsolated = scan.nextBoolean();
		System.out.println("is candidate (true\false)");
		boolean isCandidate = scan.nextBoolean();
		if (isIsolated == true) {
			System.out.println("are you wearing protective suit?(true/false)");
			boolean protectiveSuit = scan.nextBoolean();
			Infected newInfected = new Infected(name, id, year, address, isIsolated, isCandidate, protectiveSuit);
			addInfected(newInfected);
		}
		if (isCandidate == true) {
			System.out.println("enter political Party name");
			String politicalPartyName = scan.next();
			System.out.println("enter your placement");
			int placement = scan.nextInt();
			Candidate newCandidate = new Candidate(name, id, year, address, isIsolated, isCandidate, placement,
					politicalPartyName);
			addCandidate(newCandidate);
		}
		if (isCandidate == false && isIsolated == false) {
			Citizen newCitizen = new Citizen(name, id, year, address, isIsolated, isCandidate);
			addCitizen(newCitizen);
		}
	}

	public void addCitizen(Citizen newCitizen) {
		addToElectors(newCitizen);
		addToBallots(newCitizen);
	}

	public void addInfected(Infected newInfected) {
		addToElectors(newInfected);
		addToBallots(newInfected);
	}

	public void addCandidate(Candidate newCandidate) {
		findPoliticalParty(newCandidate.getPoliticalPartyName()).addCandidate(newCandidate);
		addToElectors(newCandidate);
		addToBallots(newCandidate);
	}

	public void addToElectors(Object other) {
		if (citizenCounter == this.electors.length)
			extandElectors();
		if (other instanceof Citizen)
			electors[citizenCounter] = (Citizen) other;
		else if (other instanceof Infected)
			electors[citizenCounter] = (Infected) other;
		else if (other instanceof Candidate)
			electors[citizenCounter] = (Candidate) other;
		citizenCounter++;
	}

	public void addToBallots(Object other) {
		findBallot(((Citizen) other).getWhichBallot()).addCitizensToBallot(other);
	}

	public boolean setElectors(Citizen[] newElectors) {
		this.electors = newElectors;
		return true;
	}

	public boolean extandElectors() {
		Citizen[] newElectors = new Citizen[this.electors.length * 2];
		for (int i = 0; i < this.electors.length; i++) {
			if (electors[i] != null)
				newElectors[i] = electors[i];
		}
		return setElectors(newElectors);
	}

	public void addCandidate(Scanner scan) {
		addCitizen(scan);
	}

	// ����� ���� �� ������
	public static PoliticalParty[] get_partiesList() {
		return partiesList;
	}

	public static PoliticalParty findPoliticalParty(String name) {
		for (int i = 0; i < partiesList.length; i++) {
			if (partiesList[i] != null && partiesList[i].getName().equalsIgnoreCase(name))
				return partiesList[i];
		}
		System.out.println("political party is not exist haim sheli");
		return null;
	}

	public Ballot findBallot(String address) {
		for (int i = 0; i < ballots.length; i++) {
			if (ballots[i] != null && ballots[i].getAddress().equalsIgnoreCase(address))
				return ballots[i];
		}
		System.out.println("Ballot party is not exist haim sheli");
		return null;
	}

	public static Citizen[] get_Electors() {
		return electors;
	}

	public void showAllBallots() {
		for (int i = 0; i < ballots.length; i++) {
			if (ballots[i] != null)
				System.out.println(ballots[i].toString());
		}
	}

	public void showAllCitizens() {
		for (int i = 0; i < electors.length; i++) {
			if (electors[i] != null)
				System.out.println(electors[i].toString());
		}
	}

	public void showAllPoliticalParties() {
		for (int i = 0; i < partiesList.length; i++) {
			if (partiesList[i] != null)
				System.out.println(partiesList[i].toString());
		}
	}

	public void goVote() {
		
		for (int i = 0; i < electors.length; i++) {
			Scanner s=new Scanner(System.in);
			if (electors[i] != null) {
				System.out.println("hey "+electors[i].getName()+", do you vote?(true/false)");
				boolean answer = s.nextBoolean();
				electors[i].setIsVoting(answer);
				s.nextLine();
				if (answer == true) {
					System.out.println("who are you voting for?(write the political party name)");
					String answer2 = s.nextLine();
					electors[i].setVote(answer2);
					System.out.println("thank you");
			}
		}
	}
}

	public void showElectionResult() {
		for (int i = 0; i < partiesList.length; i++) {
			if (partiesList[i] != null) {
				for (int j = 0; j < ballots.length; j++) {
					if (ballots[j] != null)
						ballots[j].showResultByPoliticalPartyName(partiesList[i].getName());
				}
			}
		}
		for (int i = 0; i < partiesList.length; i++) {
			if (partiesList[i] != null)
				System.out.println("the political party: " + partiesList[i].getName() + " have "
						+ partiesList[i].getTotalVotes() + " votes");
		}
	}

	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Elections))
			return false;

		Elections temp = (Elections) other;
		return (temp.month == month) && (temp.year == year);
	}

	@Override
	public String toString() {
		return "Elections at " + month + "//" + year;
	}

}
