package RoniVeIdan;

import java.util.Scanner;

public class Ballot {
	private enum Type {
		Regular, Soldiers, Infected
	};
	// private enum NameOfPoliticalParty {rakBibi, LuisTheDog, kingYair,
	// roniVeIdan4Ever};

	private int id;
	private String address;
	private Type type;
	private Citizen[] citizens=new Citizen[4];
	private int citizensCounter = 0;
	private int[] electionResults;
	private static int counter = 1;
	private PoliticalParty[] partiesList;
	private double percentages = 0;

	public Ballot(String address, String type) {
		this.address = address;
		this.type = Type.valueOf(type);
		this.id = counter++;
		/*for (int i = 0; i < Elections.get_Electors().length; i++) {
			if(Elections.get_Electors()[i]!=null) {
				if (Elections.get_Electors()[i].getBallot() == this.address) {
					for (int j = 0; j < citizens.length; j++) {
						if (citizens[j] == null)
							citizens[j] = Elections.get_Electors()[i];
					}
				}
			}
			
		}
		for (int i = 0; i < citizens.length; i++) {
			this.citizens[i] = citizens[i];
			countVotes(citizens[i].getVotes());
		}
		partiesList = Elections.get_partiesList();
		electionResults = new int[partiesList.length];
	}*/
	}

	public Ballot(Scanner scan) {
		this.address = scan.next();
		this.type = type.valueOf(scan.next());
		this.id = counter++;
		this.citizens = new Citizen[countVoters()];
		for (int i = 0; i < Elections.get_Electors().length; i++) {
			citizens[i] = new Citizen(scan);
		}
		partiesList = Elections.get_partiesList();
		electionResults = new int[partiesList.length];
	}

	// ����� ��� ������ �� �����
	public int countVoters() {
		int voters = 0;
		for (int i = 0; i < Elections.get_Electors().length; i++) {
			if (Elections.get_Electors()[i].getBallot() == this.address)
				voters++;
		}

		return voters;
	}

	public boolean setPercentage() {
		double counter = 0;
		for (int i = 0; i < citizens.length; i++) {
			if (citizens[i].getIsVoting())
				counter++;
		}
		this.percentages = (counter / citizens.length) * 100;
		return true;
	}

	public double getPercentage() {
		return this.percentages;
	}

	// ���� ����� ���� ������ ������� ���� �� ������
	public void countVotes(int vote) {
		for (int i = 0; i < electionResults.length; i++) {
			if (partiesList[i].getId() == vote) {
				int temp = partiesList[i].getId();
				electionResults[temp]++;
			}

		}
	}

	public String getAddress() {
		return this.address;
	}

	public void Results() {
		for (int i = 0; i < electionResults.length; i++) {
			System.out.println(electionResults[i]);
		}
	}

	// ����� ���� ���� �� ������� �������� �����
	public Citizen[] getCitizens() {
		Citizen[] coppyCitizens = new Citizen[this.citizens.length];
		for (int i = 0; i < coppyCitizens.length; i++) {
			coppyCitizens[i] = this.citizens[i];
		}
		return coppyCitizens;
	}

	public void showResultByPoliticalPartyName(String name) {
		int counter = 0;
		for (int i = 0; i < citizens.length; i++) {
			if (citizens[i] != null) {
				if (citizens[i].getIsVoting()) {
					if (citizens[i].getVote().equalsIgnoreCase(name)) {
						counter++;
						Elections.findPoliticalParty(name).setTotalVotes();
					}
				}
			}
		}
		System.out.println(
				"in ballot number " + this.id + ", political party: " + name + ", have: " + counter + " votes");
	}

	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Ballot))
			return false;

		Ballot temp = (Ballot) other;
		return (temp.id == id);
	}

	@Override
	public String toString() {
		return "Ballot " + id + ", in " + address + ", is typed for " + type + ", it has " + this.citizensCounter
				+ " voters";
	}

	public boolean addCitizensToBallot(Object other) {
		if (citizensCounter == citizens.length)
			extandCitizens();
		if (other instanceof Infected) {
			if (!((Infected) other).getProtectiveSuit())
				return false;
			if (this.type.name() != "Infected")
				return false;
			citizens[citizensCounter] = ((Infected) other);
			citizensCounter++;
		}
		if (((Citizen) other).getIsSoldier()) {
			if (this.type.name() != "Soldiers")
				return false;
			citizens[citizensCounter] = ((Citizen) other);
			citizensCounter++;
		}
		if(((Citizen)other).getIsSoldier()==false&&((Citizen)other).isIsolated==false) {
			citizens[citizensCounter] = ((Citizen) other);
			citizensCounter++;
		}
		return true;
	}

	public boolean extandCitizens() {
		Citizen[] newCitizens = new Citizen[this.citizens.length * 2];
		for (int i = 0; i < this.citizens.length; i++) {
			if (citizens[i] != null)
				newCitizens[i] = citizens[i];
		}
		return setCitizens(newCitizens);
	}

	private boolean setCitizens(Citizen[] newCitizens) {
		this.citizens = newCitizens;
		return true;
	}

}
