package RoniVeIdan;

import java.util.Scanner;

public class PoliticalParty {
	private enum Wing {Right, Left, Central};
	
	private int id;
	private String name;
	private Wing wing;
	private MyDate date;
	private Candidate []candidates;
	private static int counter=0;
	
	public PoliticalParty(String name, Wing wing, MyDate date, Candidate []candidates) {
		this.name=name;
		this.wing=wing;
		this.date=date;
		this.candidates=new Candidate[3];
		for (int i = 0; i < candidates.length; i++) {
			this.candidates[i]=candidates[i];
		}
		id=++counter;
	}
	
	public PoliticalParty(Scanner scan) {
		this.name=scan.next();
		this.wing=wing.valueOf(scan.next());
		this.date=new MyDate(scan);
		this.candidates=new Candidate[candidates.length];
		for (int i = 0; i < candidates.length; i++) {
			this.candidates[i]=candidates[i];
		}
		id=++counter;
	}
	
	public int getId() {
		return id;
	}

	public String getName() {
		return this.name;
	}
	
	@Override
	public boolean equals(Object other) {
		if(!(other instanceof PoliticalParty))
			return false;
		
		PoliticalParty temp = (PoliticalParty)other;
		return (temp.id == id);
	}
	@Override
	public String toString() {

		return "Political party " + name + ", id:" + id + ", is " + wing + " wing, created at" + date.toString()
				+ ", the party has " + candidates.length + " candidates.";
	}
}
