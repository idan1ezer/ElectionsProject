package RoniVeIdan;

import java.util.Scanner;

public class Infected extends Citizen {
	
	private boolean protectiveSuit;
	
	public Infected(String name, int id, int year, int wichBallot,boolean isIsolated, boolean protectiveSuit) {
		super(name,id,year,wichBallot,isIsolated);
		this.protectiveSuit=protectiveSuit;
	}
	
	public Infected(Scanner scan) {
		super(name,id,year,wichBallot,isIsolated,vote);
		this.protectiveSuit = scan.nextBoolean();
	}
	
	
	
	
	
	@Override
	public boolean equals(Object other) {
		if(!(other instanceof Citizen))
			return false;
		
		if(!(super.equals(other)))
			return false;
	
		return true;
	}
	@Override
	public String toString() {
		String str;
		if(protectiveSuit == true)
			str = "has protective suit";
		else
			str = "has not protective suit";
		return "Citizen " + super.getName() + ", is infected and " + str;
	}
}
