package RoniVeIdan;

import java.util.Scanner;

public class Citizen {
	
	protected String name;
	protected int id;
	protected int year;
	protected int whichBallot;
	protected boolean isIsolated;
	protected boolean isSoldier;
	protected boolean isCandidate;
	protected String vote;
	
	public Citizen(String name, int id, int year, int wichBallot,boolean isIsolated, boolean isCandidate, String vote) {
		this.name=name;
		this.id=id;
		this.year=year;
		this.whichBallot=wichBallot;
		this.isIsolated=isIsolated;
		if(year<1999||year>2002)
			this.isSoldier=false;
		else
			this.isSoldier=true;
		this.isCandidate = isCandidate;
	}
	
	public Citizen (Scanner scan) {
		this.name = scan.next();
		this.id = scan.nextInt();
		this.year = scan.nextInt();
		this.whichBallot = scan.nextInt();
		this.isIsolated = scan.nextBoolean();
		if(year<1999||year>2002)
			this.isSoldier=false;
		else
			this.isSoldier=true;
		this.isCandidate = scan.nextBoolean();
		this.vote = scan.next();
	}
	
	
	//���� �� ������ �� ����� ������� �����
	public int getVotes() {
		PoliticalParty[]parties=Elections.get_partiesList();
		for (int i = 0; i < parties.length; i++) {
			if(this.vote.equals(parties[i].getName()))
				return parties[i].getId();
		}
		return -1;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getBallot() {
		return this.whichBallot;
	}


	@Override
	public boolean equals(Object other) {
		if(!(other instanceof Citizen))
			return false;
		
		Citizen temp = (Citizen)other;
		return (temp.id == id);
	}
	@Override
	public String toString() {
		String str;
		if(isIsolated == true)
			str = "isolated";
		else
			str = "not isolated";
		return "Citizen " + name + ", id:" + id + ", " + (2020-year) + " years old, votes in" + whichBallot
				+ ", the citizen is " + str + ", and votes for " + vote;
	}
	
	
	
	
	
}
