package RoniVeIdan;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		StartElection();

		
		

	}
	
	public static void StartElection() throws FileNotFoundException {
		Scanner scan = new Scanner(new File("C:\\house.txt"));
		Elections elections = new Elections(scan);
		scan.close();
		
	}

}
