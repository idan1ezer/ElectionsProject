package RoniVeIdan;

import java.util.Scanner;

public class Candidate extends Citizen{
	
	private int politicalPartyId;
	private int placement;
	
	public Candidate(String name, int id, int year, int wichBallot,boolean isIsolated,boolean isCandidate, String vote, int placement, int politicalPartyId) {
		super(name,id,year,wichBallot,isIsolated,isCandidate,vote);
		this.placement=placement;
		this.politicalPartyId=politicalPartyId;
	}
	
	public Candidate(Scanner scan) {
		super(name,id,year,wichBallot,isIsolated,isCandidate,vote);
		this.placement = scan.nextInt();
		this.politicalPartyId = scan.nextInt();
	}
	
	//����� �� �������� ��� ����
	public static void insertionSort(Candidate[] arr) {
		for (int i=1 ; i < arr.length ; i++) {
			for (int j=i ; j > 0 && arr[j-1].placement > arr[j].placement ; j--) {
				Candidate temp = arr[j];
				arr[j] = arr[j-1];
				arr[j-1] = temp;
				}
			}
		}
	
	@Override
	public boolean equals(Object other) {
		if(!(other instanceof Citizen))
			return false;
		
		if(!(super.equals(other)))
			return false;
		
		Candidate temp = (Candidate)other;
		return (temp.placement == placement) && (temp.politicalPartyId == politicalPartyId);
	}
	@Override
	public String toString() {
		return "Citizen " + super.getName() + ", is candidate for " + politicalPartyId + ", he is placed at " + placement;
	}

}