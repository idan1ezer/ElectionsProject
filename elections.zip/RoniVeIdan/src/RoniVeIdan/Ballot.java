package RoniVeIdan;

import java.util.Scanner;

public class Ballot {
	private enum Type {Regular, Soldiers, Infected};
	
	private int id;
	private String address;
	private Type type;
	private Citizen[]citizens;
	private int[]electionResults;
	private static int counter=1;
	private PoliticalParty[] partiesList;
	
	public Ballot(String address, Type type) {
		this.address = address;
		this.type = type;
		this.id = counter++;
		this.citizens = new Citizen[countVoters()];
		for (int i = 0; i < Elections.get_Electors().length; i++) {
			if(Elections.get_Electors()[i].getBallot() == this.id) {
				for (int j = 0; j < citizens.length; j++) {
					if(citizens[j] == null)
						citizens[j] = Elections.get_Electors()[i];
				}
			}
		}	
		for (int i = 0; i < citizens.length; i++) {
			this.citizens[i] = citizens[i];
			countVotes(citizens[i].getVotes());
		}
		partiesList = Elections.get_partiesList();
		electionResults = new int[partiesList.length];
	}
	
	public Ballot(Scanner scan) {
		this.address = scan.next();
		this.type = type.valueOf(scan.next());
		this.id = counter++;
		this.citizens = new Citizen[countVoters()];
		for (int i = 0; i < Elections.get_Electors().length; i++) {
			if(Elections.get_Electors()[i].getBallot() == this.id) {
				for (int j = 0; j < citizens.length; j++) {
					if(citizens[j] == null)
						citizens[j] = Elections.get_Electors()[i];
				}
			}
		}
		for (int i = 0; i < citizens.length; i++) {
			this.citizens[i] = citizens[i];
			countVotes(citizens[i].getVotes());
		}
		partiesList = Elections.get_partiesList();
		electionResults = new int[partiesList.length];
	}
	
	public int countVoters() {
		int voters = 0;
		for (int i = 0; i < Elections.get_Electors().length; i++) {
			if(Elections.get_Electors()[i].getBallot() == this.id)	
				voters ++;
		}
		
		return voters;
	}
	
	
	//���� ����� ���� ������ ������� ���� �� ������
	public void countVotes(int vote){
		for (int i = 0; i < electionResults.length; i++) {
			if(partiesList[i].getId() == vote) {
				int temp = partiesList[i].getId();
				electionResults[temp]++;
			}
				
		}
	}
	
	public void Results() {
		for (int i = 0; i < electionResults.length; i++) {
			System.out.println(electionResults[i]);
		}
	}
	
	@Override
	public boolean equals(Object other) {
		if(!(other instanceof Ballot))
			return false;
			
		Ballot temp = (Ballot)other;
		return (temp.id == id);
	}
	@Override
	public String toString() {
		return "Ballot " + id + ", in " + address + ", is typed for " + type + ", it has " + citizens.length
				+ " voters";
	}
			
}
