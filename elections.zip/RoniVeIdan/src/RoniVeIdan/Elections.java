package RoniVeIdan;

import java.util.Scanner;

public class Elections {
	
	private int month;
	private int year;
	
	private static Citizen [] electors = new Citizen[37];
	private static PoliticalParty[] partiesList = new PoliticalParty[4];
//	private static Candidate[] candidates;
	private Ballot []ballots = new Ballot[5];
	
	public Elections(int month, int year) {
		this.month = month;
		this.year = year;
	}
	
	public Elections(Scanner scan) {
		this.month = scan.nextInt();
		this.year = scan.nextInt();
		for (int i = 0; i < electors.length; i++) {
			electors[i] = new Citizen(scan);
		}
		for (int i = 0; i < partiesList.length; i++) {
			partiesList = new PoliticalParty(scan);
		}
		for (int i = 0; i < ballots.length; i++) {
			ballots = new Ballot(scan);
		}
		scan.close();
	}
	
	
	
	
	
	public void addParty(PoliticalParty party) {
		for (int i = 0; i < partiesList.length; i++) {
			if (partiesList[i] == null)
				partiesList[i] = party;
		} 
	}
	//����� ���� �� ������
	public static PoliticalParty[] get_partiesList(){
		return partiesList;
	}
	
	public static Citizen[] get_Electors(){
		return electors;
	}
	
	@Override
	public boolean equals(Object other) {
		if(!(other instanceof Elections))
			return false;
			
		Elections temp = (Elections)other;
		return (temp.month == month) && (temp.year == year);
	}
	@Override
	public String toString() {
		return "Elections at " + month + "//" + year;
	}
}
