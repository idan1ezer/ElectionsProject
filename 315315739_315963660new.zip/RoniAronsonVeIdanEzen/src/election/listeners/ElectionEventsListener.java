package election.listeners;

import java.time.LocalDate;

import id315315739_id315963660.Citizen;

public interface ElectionEventsListener {
	
}
