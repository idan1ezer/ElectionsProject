package id315315739_id315963660;

public interface Sickable {
	
	boolean setProtectiveSuit(boolean protectiveSuit);
	boolean getProtectiveSuit();
	
	boolean setHowManyDays(int howManyDays);
	int getHowManyDays();
	
	String toString();
}

